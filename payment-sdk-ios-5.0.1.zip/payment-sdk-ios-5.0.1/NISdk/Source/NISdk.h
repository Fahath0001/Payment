//
//  NISdk.h
//  NISdk
//
//  Created by Johnny Peter on 08/08/19.
//  Copyright © 2019 Network International. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NISdk.
FOUNDATION_EXPORT double NISdkVersionNumber;

//! Project version string for NISdk.
FOUNDATION_EXPORT const unsigned char NISdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NISdk/PublicHeader.h>


