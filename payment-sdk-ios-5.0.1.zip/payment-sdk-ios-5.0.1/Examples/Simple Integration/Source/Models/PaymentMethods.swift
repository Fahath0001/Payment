//
//  PaymentMethods.swift
//  Simple Integration
//
//  Created by Johnny Peter on 27/08/19.
//  Copyright © 2019 Network International. All rights reserved.
//

import Foundation

public enum PaymentMethod {
    case Card
    case ApplePay
}
